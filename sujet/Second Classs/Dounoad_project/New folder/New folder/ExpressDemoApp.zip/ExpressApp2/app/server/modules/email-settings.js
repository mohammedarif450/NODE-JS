
module.exports = {
	
    host: 'smtp.gmail.com',
    user: 'demo.oaapt@gmail.com',
    password: 'oaapt@123',
    sender: 'Demo-OAAPT<demo.oaapt@gmail.com>'
}